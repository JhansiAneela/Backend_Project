package com.example.cartservice.model;

import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="cart")
public class Cart {
	
	@Id
	private int id;
	private String name;
	private int salary;
	private String company;
	
	public Cart(int id, String name, int salary, String company) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.company = company;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}


	@Override
	public String toString() {
		return "Cart [id=" + id + ", name=" + name + ", salary=" + salary + ", company=" + company + "]";
	}
	
	
	

}
