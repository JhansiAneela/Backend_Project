package com.example.cartservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cartservice.model.Cart;
import com.example.cartservice.service.CartService;


@RestController
@RequestMapping("/cartdetails")

public class CartController {
	
	@Autowired
	private CartService service;
	
	@PostMapping("/Addcart")
    public ResponseEntity<String> addToCart(@RequestBody Cart cart) {

        if(cart.getId()>0){

        service.addToCart(cart);

        return ResponseEntity.ok("Employee added to cart successfully");

    }

    else{

        return ResponseEntity.ok("Employee doesnot added to the cart successfully");

        }

    }

}
