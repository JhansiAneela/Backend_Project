package com.example.cartservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cartservice.model.Cart;
import com.example.cartservice.repository.CartRepository;

@Service
public class CartService {
	
	@Autowired
	private CartRepository repository;

	public void addToCart(Cart cart) {
		
		if(cart.getId()>0){

            repository.save(cart);

        }
		


	}

}
